

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">My Events</div>
                <div class="card-body">
                    <?php if(session('success')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('success')); ?>

                        </div>
                    <?php endif; ?>

                    <h3>Welcome, <?php echo e(Auth::user()->name); ?>!</h3>

                    <?php if(Auth::user()->role === 'organizer'): ?>
                        <p>You are logged in as an organizer.</p>
                        <a href="<?php echo e(route('events.create')); ?>" class="btn btn-primary">Create Event</a>
                    <?php elseif(Auth::user()->role === 'attendee'): ?>
                        <p>You are logged in as an attendee.</p>
                    <?php endif; ?>
                </div>
                <div class="card-body">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Title</th>
                                <th>Date</th>
                                <th>Location</th>
                                <th>Tickets Available</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($event->title); ?></td>
                                <td><?php echo e($event->date->format('M d, Y H:i A')); ?></td>
                                <td><?php echo e($event->location); ?></td>
                                <td><?php echo e($event->ticket_availability); ?></td>
                                <td>
                                    <a href="<?php echo e(route('events.edit', $event->id)); ?>" class="btn btn-sm btn-primary">Edit</a>
                                    <button class="btn btn-sm btn-danger delete-event" data-id="<?php echo e($event->id); ?>">Delete</button>
                                    <a href="<?php echo e(route('events.attendees', $event->id)); ?>" class="btn btn-sm btn-info">View Attendees</a>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    $(document).ready(function() {
        $('.delete-event').on('click', function() {
            if (confirm('Are you sure you want to delete this event?')) {
                const eventId = $(this).data('id');

                $.ajax({
                    url: '/events/' + eventId,
                    method: 'DELETE',
                    headers: {
                        'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
                    },
                    success: function(response) {
                        alert(response.message);
                        location.reload();
                    },
                    error: function(xhr) {
                        alert('Error deleting event: ' + xhr.responseText);
                    }
                });
            }
        });
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\online-ticketing 1\resources\views/events/index.blade.php ENDPATH**/ ?>