

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header"><?php echo e(__('Dashboard')); ?></div>

                    <div class="card-body">
                        <?php if(session('success')): ?>
                            <div class="alert alert-success" role="alert">
                                <?php echo e(session('success')); ?>

                            </div>
                        <?php endif; ?>

                        <h3>Welcome, <?php echo e(Auth::user()->name); ?>!</h3>

                        <?php if(Auth::user()->role === 'organizer'): ?>
                            <p>You are logged in as an organizer.</p>
                            <a href="<?php echo e(route('events.create')); ?>" class="btn btn-primary">Create Event</a>
                        <?php elseif(Auth::user()->role === 'attendee'): ?>
                            <p>You are logged in as an attendee.</p>
                            <a href="<?php echo e(route('tickets')); ?>" class="btn btn-primary">View Ticket</a>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\online-ticketing 1\resources\views/dashboard.blade.php ENDPATH**/ ?>