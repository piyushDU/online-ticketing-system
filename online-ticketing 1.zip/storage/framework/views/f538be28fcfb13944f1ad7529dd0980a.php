 
<?php $__env->startSection('title', 'Payment Canceled'); ?> 
<?php $__env->startSection('content'); ?> 
<div class="container mt-5">
    <div class="alert alert-danger">
        <h4>Payment Canceled!</h4>
        <p>Your payment was canceled. Please try again.</p>
    </div>
</div> 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\online-ticketing 1\resources\views/tickets/cancel.blade.php ENDPATH**/ ?>