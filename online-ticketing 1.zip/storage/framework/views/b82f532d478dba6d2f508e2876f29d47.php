

<?php $__env->startSection('title', 'Ticket Sales'); ?>

<?php $__env->startSection('content'); ?>
<div class="container mt-5">
    <div class="row">
        <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-4">
            <div class="card mb-4">
                <div class="card-header">
                    <h5 class="card-title"><?php echo e($event->title); ?></h5>
                </div>
                <div class="card-body">
                    <p class="card-text"><?php echo e($event->description); ?></p>
                    <h6>Ticket Types:</h6>
                    <form>
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="event_id" value="<?php echo e($event->id); ?>">
                        <ul class="list-group mb-3">
                            <?php $__currentLoopData = $event->ticketTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ticket): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="list-group-item">
                                <div class="form-check">
                                    <input class="form-check-input" type="radio" data-ticket="<?php echo e($ticket->id); ?>" data-id="<?php echo e($event->id); ?>" name="ticket_type_id<?php echo e($event->id); ?>"  id="ticket<?php echo e($ticket->id); ?>" value="<?php echo e($ticket->price); ?>" data-name="<?php echo e($ticket->name); ?>" <?php echo e($event->ticket_availability ? '' : 'disabled'); ?>>
                                    <label class="form-check-label" for="ticket<?php echo e($ticket->id); ?>">
                                        <?php echo e($ticket->name); ?> - $<?php echo e($ticket->price); ?>

                                        <?php if($event->ticket_availability): ?>
                                        <span class="badge badge-success float-right">Available</span>
                                        <?php else: ?>
                                        <span class="badge badge-danger float-right">Sold Out</span>    
                                        <?php endif; ?>
                                    </label>
                                    
                                </div>
                            </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                        <div class="input-group mb-3">
                        <div class="input-group-prepend">
                            <button type="button" class="btn btn-outline-secondary decrement-btn" data-id="<?php echo e($event->id); ?>" data-target="#quantity<?php echo e($event->id); ?>">-</button>
                        </div>
                        <input type="text" class="form-control quantity-input" style="max-width: 17%;" id="quantity<?php echo e($event->id); ?>" name="ticket_quantities" value="0" min="0" max="<?php echo e($event->max_tickets); ?>">
                        <div class="input-group-append">
                            <button type="button" class="btn btn-outline-secondary increment-btn" data-id="<?php echo e($event->id); ?>" data-target="#quantity<?php echo e($event->id); ?>">+</button>
                        </div>
                        <div class="ml-3 total-price total-price<?php echo e($event->id); ?>">$0.00</div>
                    </div>
                        <button type="button" class="btn btn-primary submit" data-id="<?php echo e($event->id); ?>">Purchase Ticket</button>
                    </form>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script src="https://js.stripe.com/v3/"></script>
<script>
    $(document).ready(function() {
        var count = 0;   
        $(document).on('click','.increment-btn', function() {
            // let eventId = $(this).data('id');
            // let ticketCount = $("#quantity"+ eventId).val();
            // count = count + 1;
            // $("#quantity"+ eventId).val(count);
            var eventId = $(this).data('id');
            var targetInput = $("#quantity" + eventId);
            var currentValue = parseInt(targetInput.val()) || 0; // Default to 0 if input value is empty
            var maxValue = parseInt(targetInput.attr('max')) || 10; // Default max value (adjust as needed)

            if (currentValue < maxValue) {
                currentValue++;
                targetInput.val(currentValue);
                updateTotalPrice(currentValue, eventId);
            }
            });
        });
        
        $(document).on('click','.decrement-btn', function() {
            // let eventId = $(this).data('id');
            // let ticketCount = $("#quantity"+ eventId).val();
            // console.log('ticketCount', ticketCount);
            // count = count - 1;
            // console.log('count', count);
            // $("#quantity"+ eventId).val(count);
            var eventId = $(this).data('id');
            var targetInput = $("#quantity" + eventId);
            var currentValue = parseInt(targetInput.val()) || 0; // Default to 0 if input value is empty

            if (currentValue > 0) {
                currentValue--;
                targetInput.val(currentValue);
                updateTotalPrice(currentValue, eventId);
            }
        });

    $(document).on('input', '.quantity-input', function() {
        updateTotalPrice();
    });

    $(document).on('click', '.form-check-input', function() {
        let eventId = $(this).data('id');
        $('.total-price'+eventId).text(`$0.00`);
        $('#quantity'+eventId).val(0);
        $(this)
    });

    function updateTotalPrice(quantity, eventId) {
        var totalPrice = 0;
        let price = $(`input[name="ticket_type_id${eventId}"]:checked`).val();
        if(price) {
            console.log('price', price);
            let ticketPrice = $("#ticket"+eventId).val();
            let ticketType = $("#ticket"+eventId).data("name");

            console.log('ticketPrice', ticketPrice);
            console.log('ticketType', ticketType);

            var quantity = parseInt(quantity);
            console.log('quantity', quantity);
            totalPrice += quantity * parseInt(price);
            
            $('.total-price'+eventId).text(`$ ${totalPrice.toFixed(2)}`);
        }
    }
    var stripe = Stripe('<?php echo e(env('STRIPE_KEY')); ?>');
    $(document).on('click', '.submit', function() {
        let eventId = $(this).data("id");
        let ticketTypeId = $(`input[name="ticket_type_id${eventId}"]:checked`).data('ticket');
        var price = $(`input[name="ticket_type_id${eventId}"]:checked`).val();
        var quantity =  $('#quantity'+eventId).val();
        if(quantity <= 0) {
            alert('Please select Quantity');
            return;
        } else if(!price) {
            alert('Please select Ticket Type');
            return;
        }

        $.ajax({
                url: '<?php echo e(route('tickets.purchase')); ?>',
                method: 'POST',
                data: {eventId: eventId, ticketTypeId:ticketTypeId, price: price,  quantity: quantity},
                headers: {
                    'X-CSRF-TOKEN': $('input[name="_token"]').val(),
                },
                success: function(response) {
                    return stripe.redirectToCheckout({ sessionId: response.id });
                },
                error: function(xhr) {
                    alert('Error creating event: ' + xhr.responseText);
                }
            });
        
        console.log('eventId', eventId);
        console.log('ticketTypeId', ticketTypeId);
        console.log('price', price);
        console.log('quantity', quantity);
    });

</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\online-ticketing 1\resources\views/tickets/tickets.blade.php ENDPATH**/ ?>