@extends('layouts.app')
@section('title', 'Payment Success') 
@section('content') 
<div class="container mt-5"> 
    <div class="alert alert-success"> 
            <h4>Payment Successful!</h4>
                <p>Thank you for your purchase. Your ticket has been successfully purchased.</p> 
    </div>
</div>
@endsection